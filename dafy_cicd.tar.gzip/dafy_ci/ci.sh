#!/bin/bash


#JOB_CI-shell:
#cd /home/jenkins/workspace
#chmod 777 /home/jenkins/$JOB_NAME/ci.sh
#cd $JOB_NAME
#sh ci.sh

/usr/local/maven/bin/mvn clean package install -U -Dmaven.test.skip=true -P test

[ $? -ne 0 ] && echo "打包失败，请检查" && exit 7

#检查期待的包是否存在
while read LINE;do			   

	ls $LINE &> /dev/null
	[ $? -ne 0 ] && echo "集成失败，未找到该文件 ${LINE##*/}" && exit 8
			    
done <  ./check-package

#获取时间搓
export TIME=`date +%s`
echo $TIME > ./time.txt
export D_TIME=_$TIME

#将生产的包放置NFS盘上

while read LINE;do
	#更换部署包目录，并按时间搓标记

        mv $LINE     /data/${LINE##*/}$D_TIME

done <  ./check-package

#更改cd.sh中的TIME变量
#T=`cat ./cd.sh |grep "TIME="`
#P="TIME=$TIME"
#sed -i '1,$s@'"$T"'@'"$P"'@' cd.sh

echo "本次集成已完成"
