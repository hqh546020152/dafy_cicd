文件说明：
ci.sh		集成脚本脚本（依赖check-package）
check-package	存放数据包生成名称及路径

使用方式：
将ci.sh与check-package放置项目根下即可



