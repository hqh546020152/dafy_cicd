文件说明：
cd.sh		自动更新脚本（依赖time.txt、check-package）
time.txt	保持本次要更新时间搓
roll.sh		手动回滚代码脚本(依赖cd.sh、time.txt)
check-package	存放数据包生成名称及路径

使用方式：
将以上文件放置更新目标服务器的/root/.devops目录下

cd自动部署过程中需用到
	cd.sh
	time.txt
	check-package

代码回滚目前使用手动的方式进行操作，步骤如下
1、登录回滚代码目标服务器上
2、cd /root/.devops
3、sh roll.sh
4、选择要回滚的时间戳
5、确认并开始执行

