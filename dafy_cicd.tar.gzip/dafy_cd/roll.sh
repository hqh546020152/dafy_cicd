#!/bin/bash
#

#该脚本用于手动回滚

clear

ls /data |grep "bin.zip"| cut -d "_" -f2 |sort -rn |uniq > mini_test.txt
A=`cat mini_test.txt |wc -l`

#可回滚的版本如下
hint(){
	for  I  in  `seq 1 $A`;do
		B=`cat mini_test.txt | head -$I | tail -1`
		C=`date -d @$B`
		echo "$B  对应时间:$C"
	done
}

hint
while    :; do				   
				    
	read -p "请输入要回滚版本的时间戳,取消请输入"q"
>>>" TIME_ROLL
	[ $TIME_ROLL == q ] && exit 0
	cat mini_test.txt | grep $TIME_ROLL &> /dev/null
	if [ $? -ne 0 ];then
		echo "不在该版本，请重新输入" 
		continue
	else
		read -p "请确认一下是否要回滚到$TIME_ROLL版本,版本生产时间为`date -d @$TIME_ROLL`,确认请输入"y"
>>>" TIME_ROLL_2
		if [ $TIME_ROLL_2 == y ];then 
			break
		else
			clear
			hint
			continue				
		fi
	fi
done

echo "正在回滚至$TIME_ROLL版本中，请等候"

Y_TIME=`cat time.txt`
echo $TIME_ROLL > time.txt
sh cd.sh
echo $Y_TIME > time.txt

