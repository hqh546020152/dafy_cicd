#!/bin/bash
#


#JOB_CD
#参数化构建过程:
#dirname=JOB_ci_NAME
#JOB_CD-shell:
#export dir_name=$dirname
#ansible dev2 -m copy -a "src=/data/ dest=/data/ "
#ansible dev2 -m copy -a "src=/home/jenkins/workspace/dafy_dev_ci/time.txt dest=/root/.devops/ "
#ansible dev2 -m shell -a "cd /root/.devops && sh cd.sh"

kill_course(){
	ps -ef |grep task-rpc|grep -v "grep"|awk '{print $2}'|xargs kill -9 &> /dev/null
	ps -ef |grep repay-rpc|grep -v "grep"|awk '{print $2}'|xargs kill -9 &> /dev/null
	ps -ef |grep report-rpc|grep -v "grep"|awk '{print $2}'|xargs kill -9 &> /dev/null
	ps -ef |grep admin-server|grep -v "grep"|awk '{print $2}'|xargs kill -9 &> /dev/null
	ps -ef |grep app-server|grep -v "grep"|awk '{print $2}'|xargs kill -9 &> /dev/null
	ps -ef |grep firstparty-server|grep -v "grep"|awk '{print $2}'|xargs kill -9 &> /dev/null
	ps -ef |grep outsource-server|grep -v "grep"|awk '{print $2}'|xargs kill -9 &> /dev/null
sleep 10
}


check_course(){
#检查是否已将进程杀死了，如值大于2则说明未杀死
	CHECK=`ps -ef |grep task-rpc |wc -l`
	[ $CHECK -ge 2 ] && return 12
	CHECK=`ps -ef |grep repay-rpc|wc -l`
	[ $CHECK -ge 2 ] && return 12
	CHECK=`ps -ef |grep report-rpc|wc -l`
	[ $CHECK -ge 2 ] && return 12
	CHECK=`ps -ef |grep admin-server|wc -l`
	[ $CHECK -ge 2 ] && return 12
	CHECK=`ps -ef |grep app-server|wc -l`
	[ $CHECK -ge 2 ] && return 12
	CHECK=`ps -ef |grep firstparty-server|wc -l`
	[ $CHECK -ge 2 ] && return 12
	CHECK=`ps -ef |grep outsource-server|wc -l`
	[ $CHECK -ge 2 ] && return 12
}



drop_code(){
#删除原来数据
	cd /opt/server/OneCollection/onecollection-rpc/repay-rpc
	rm -rf * && sleep 1
	cd /opt/server/OneCollection/onecollection-rpc/task-rpc
	rm -rf * && sleep 1
	cd /opt/server/OneCollection/onecollection-rpc/report-rpc
	rm -rf * && sleep 1
	cd /opt/server/OneCollection/onecollection-cgi/app-server
	rm -rf * && sleep 1
	cd /opt/server/OneCollection/onecollection-cgi/admin-server
	rm -rf * && sleep 1
	cd /opt/server/OneCollection/onecollection-cgi/firstparty-server
	rm -rf * && sleep 1
	cd /opt/server/OneCollection/onecollection-cgi/outsource-server
	rm -rf * && sleep 1
}

cp_code(){
	CODE=`ls /data |grep "admin-server" |grep $TIME`
	cp /data/$CODE /opt/server/OneCollection/onecollection-cgi/admin-server/

	CODE=`ls /data |grep "app-server" |grep $TIME`
	cp /data/$CODE /opt/server/OneCollection/onecollection-cgi/app-server/

	CODE=`ls /data |grep "firstparty-server" |grep $TIME`
	cp /data/$CODE /opt/server/OneCollection/onecollection-cgi/firstparty-server/

	CODE=`ls /data |grep "outsource-server" |grep $TIME`
	cp /data/$CODE /opt/server/OneCollection/onecollection-cgi/outsource-server/

	CODE=`ls /data |grep "report-provider" |grep $TIME`
	cp /data/$CODE /opt/server/OneCollection/onecollection-rpc/report-rpc/

	CODE=`ls /data |grep "task-provide" |grep $TIME`
	cp /data/$CODE /opt/server/OneCollection/onecollection-rpc/task-rpc/

	CODE=`ls /data |grep "repay-provider" |grep $TIME`
	cp /data/$CODE /opt/server/OneCollection/onecollection-rpc/repay-rpc/
}

#启动进程
start_course(){
	cd /opt/server/OneCollection/onecollection-rpc/repay-rpc
	unzip repay-provider-2.0.0-SNAPSHOT-bin.zip*
	cd bin && chmod 711 *.sh
	./start.sh product
	sleep 1
	cd /opt/server/OneCollection/onecollection-rpc/task-rpc
	unzip task-provider-2.0.0-SNAPSHOT-bin.zip*
	cd bin && chmod 711 *.sh
	./start.sh product
	sleep 1
	cd /opt/server/OneCollection/onecollection-rpc/report-rpc
	unzip report-provider-2.0.0-SNAPSHOT-bin.zip*
	cd bin && chmod 711 *.sh
	./start.sh product
	sleep 1

	cd /opt/server/OneCollection/onecollection-cgi/app-server
	unzip app-server-2.0.0-SNAPSHOT-bin.zip*
	cd bin && chmod 711 *.sh
	./start.sh product
	sleep 1
	cd /opt/server/OneCollection/onecollection-cgi/admin-server
	unzip admin-server-2.0.0-SNAPSHOT-bin.zip*
	cd bin && chmod 711 *.sh
	./start.sh product
	sleep 1
	cd /opt/server/OneCollection/onecollection-cgi/firstparty-server
	unzip firstparty-server-2.0.0-SNAPSHOT-bin.zip*
	cd bin && chmod 711 *.sh
	./start.sh product
	sleep 1
	cd /opt/server/OneCollection/onecollection-cgi/outsource-server
	unzip outsource-server-2.0.0-SNAPSHOT-bin.zip*
	cd bin && chmod 711 *.sh
	./start.sh product
	sleep 1
}

#检查目前存在的检查数
A=`jps |grep "2.0.0"|wc -l`

ls ./time.txt &> /dev/null
[ $? -ne 0 ] && echo "缺失time.txt文件" && exit 9
ls ./check-package &> /dev/null
[ $? -ne 0 ] && echo "缺失check-package文件" && exit 9
TIME=`cat ./time.txt`
[ $TIME -lt 1500000000 ] && echo "时间戳异常请检查" && exit 10

#获取原来包的时间戳，可做对比判断
CT=`ls /opt/server/OneCollection/onecollection-cgi/admin-server/admin-server-2.0.0-SNAPSHOT-bin.zip*`
CTY=`echo ${CT##*_}`
[ $TIME -eq $CTY ] && echo "时间搓一致，无须替换" && exit 11

#检查要更新的包是否存在
while read LINE;do
	#echo $LINE
	#echo $TIME
	#echo "/data/${LINE##*/}_$TIME"
        ls /data/${LINE##*/}_$TIME &> /dev/null
        [ $? -ne 0 ] && echo "未找到该文件 ${LINE##*/}_$TIME" && exit 8

done <  ./check-package

for  I  in  `seq 1 7`;do

	kill_course
	check_course
	[ $? -ne 12 ] && break 	
done

check_course
[ $? -eq 12 ] && echo "不能正常结束原有进程，请检查" && exit 13

#删除原有code
drop_code

#cp本次要更新的code
cp_code

#启动进程
start_course

sleep 15
B=`jps |grep "2.0.0"|wc -l`
[ $A -le $B ] && echo "更新成功" && exit 0

kill_course
sleep 2
start_course

sleep 10
B=`jps |grep "2.0.0"|wc -l`
[ $A -le $B ] && echo "更新成功" && exit 0
[ $A -ne $B ] && echo "失败请检查进程无法启动原因" && exit 22

