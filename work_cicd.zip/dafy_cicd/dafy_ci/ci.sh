#!/bin/bash


#更新记录
#20171212       自动编译测试环境数据包
#20171225       增加环境判断，增加对预发、正式环境打包功能


#JENKINS_DEV_CI

#cd /home/jenkins/workspace
#chmod 777 /home/jenkins/$JOB_NAME/ci.sh
#cd $JOB_NAME
#sh ci.sh dev

ENVI=$1

[ $ENVI -z ] &> /dev/null
#执行该脚本格式sh ci.sh dev
[ $? -eq 0 ] && echo "无定义环境！请输入执行的环境变量：测试环境为dev、预发环境为pre、正式环境为prod" && exit 9

case $ENVI in
test)
        echo "正在为开发环境打包代码"
        /usr/local/maven/bin/mvn clean package install -U -Dmaven.test.skip=true -P dev
        [ $? -ne 0 ] && echo "打包失败，请检查" && exit 7
        ;;
dev)
        echo "正在为测试环境打包代码"
        /usr/local/maven/bin/mvn clean package install -U -Dmaven.test.skip=true -P test
        [ $? -ne 0 ] && echo "打包失败，请检查" && exit 7
        ;;
pre)
        echo "正在为预发环境打包代码"
        /usr/local/maven/bin/mvn clean package install -U -Dmaven.test.skip=true -P pre
        [ $? -ne 0 ] && echo "打包失败，请检查" && exit 7
        ;;
prod)
        echo "正在为正式环境打包代码"
        /usr/local/maven/bin/mvn clean package install -U -Dmaven.test.skip=true -P product
        [ $? -ne 0 ] && echo "打包失败，请检查" && exit 7
        ;;
*)
        echo "不存在$ENVI环境,请检查传入参数"
        exit 12
        ;;
esac

if [ $ENVI == test ];then
        ENVI=dev
fi

#/usr/local/maven/bin/mvn clean package install -U -Dmaven.test.skip=true -P test
#[ $? -ne 0 ] && echo "打包失败，请检查" && exit 7

#检查期待的包是否存在
while read LINE;do

        ls $LINE &> /dev/null
        [ $? -ne 0 ] && echo "集成失败，未找到该文件 ${LINE##*/}" && exit 8

done <  ./check-package

#获取时间搓
export TIME=`date +%s`
echo $TIME > ./time.txt
export D_TIME=_$TIME

#将生产的包放置NFS盘上

case    $ENVI in
test)
        while read LINE;do
                #更换部署包目录，并按时间搓标记
                mv $LINE     /data/${LINE##*/}"$D_TIME"_"$ENVI"
        done <  ./check-package
        ;;
dev)
        while read LINE;do
                #更换部署包目录，并按时间搓标记
                mv $LINE     /data/${LINE##*/}"$D_TIME"_"$ENVI"
        done <  ./check-package
        ;;
*)
        while read LINE;do
                #更换部署包目录，并按时间搓标记
                mv $LINE     /data_pro/${LINE##*/}"$D_TIME"_"$ENVI"
        done <  ./check-package
        ;;
esac

#更改cd.sh中的TIME变量
#T=`cat ./cd.sh |grep "TIME="`
#P="TIME=$TIME"
#sed -i '1,$s@'"$T"'@'"$P"'@' cd.sh

echo "本次集成已完成"