#!/bin/bash
#


kill_course(){
	ps -ef |grep task-rpc|grep -v "grep"|awk '{print $2}'|xargs kill -9 &> /dev/null
	ps -ef |grep repay-rpc|grep -v "grep"|awk '{print $2}'|xargs kill -9 &> /dev/null
	ps -ef |grep report-rpc|grep -v "grep"|awk '{print $2}'|xargs kill -9 &> /dev/null
	ps -ef |grep admin-server|grep -v "grep"|awk '{print $2}'|xargs kill -9 &> /dev/null
	ps -ef |grep app-server|grep -v "grep"|awk '{print $2}'|xargs kill -9 &> /dev/null
	ps -ef |grep firstparty-server|grep -v "grep"|awk '{print $2}'|xargs kill -9 &> /dev/null
	ps -ef |grep outsource-server|grep -v "grep"|awk '{print $2}'|xargs kill -9 &> /dev/null
sleep 10
}


#启动进程
start_course(){
	cd /opt/server/OneCollection/onecollection-rpc/repay-rpc
	#unzip repay-provider-2.0.0-SNAPSHOT-bin.zip*
	cd bin && chmod 711 *.sh
	./start.sh product
	sleep 1
	cd /opt/server/OneCollection/onecollection-rpc/task-rpc
	#unzip task-provider-2.0.0-SNAPSHOT-bin.zip*
	cd bin && chmod 711 *.sh
	./start.sh product
	sleep 1
	cd /opt/server/OneCollection/onecollection-rpc/report-rpc
	#unzip report-provider-2.0.0-SNAPSHOT-bin.zip*
	cd bin && chmod 711 *.sh
	./start.sh product
	sleep 1

	cd /opt/server/OneCollection/onecollection-cgi/app-server
	#unzip app-server-2.0.0-SNAPSHOT-bin.zip*
	cd bin && chmod 711 *.sh
	./start.sh product
	sleep 1
	cd /opt/server/OneCollection/onecollection-cgi/admin-server
	#unzip admin-server-2.0.0-SNAPSHOT-bin.zip*
	cd bin && chmod 711 *.sh
	./start.sh product
	sleep 1
	cd /opt/server/OneCollection/onecollection-cgi/firstparty-server
	#unzip firstparty-server-2.0.0-SNAPSHOT-bin.zip*
	cd bin && chmod 711 *.sh
	./start.sh product
	sleep 1
	cd /opt/server/OneCollection/onecollection-cgi/outsource-server
	#unzip outsource-server-2.0.0-SNAPSHOT-bin.zip*
	cd bin && chmod 711 *.sh
	./start.sh product
	sleep 1
}

kill_course
start_course
