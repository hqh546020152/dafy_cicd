#!/bin/bash
#

#CD-JOB=dafy_dev_cd
#dirname=dafy_dev_ci
#export dir_name=$dirname
#ansible dev2 -m copy -a "src=/data/ dest=/data/ "
#ansible dev2 -m copy -a "src=/home/jenkins/workspace/dafy_dev_ci/time.txt dest=/root/.devops/ "
#ansible dev2 -m shell -a "cd /root/.devops && sh cd.sh dev"


PWD_DIR=`pwd`
ENVI=$1
[ $ENVI -z ] &> /dev/null
#执行该脚本格式sh ci.sh dev
[ $? -eq 0 ] && echo "无定义环境！请输入执行的环境变量：测试环境为dev、预发环境为pre、正式环境为prod" && exit 9


case $ENVI in
dev)
	sh weixin_massage.sh "测试环境正在更新，请知悉"
	;;
pre)
	sh weixin_massage.sh "预发环境正在更新，请知悉"
        ;;
prod)
	sh weixin_massage.sh "正式环境正在更新，请知悉"
        ;;
*)
	echo "不存在$ENVI环境,请检查传入参数"
	exit 25
	;;	
esac

kill_course(){
	ps -ef |grep task-rpc|grep -v "grep"|awk '{print $2}'|xargs kill -9 &> /dev/null
	ps -ef |grep repay-rpc|grep -v "grep"|awk '{print $2}'|xargs kill -9 &> /dev/null
	ps -ef |grep report-rpc|grep -v "grep"|awk '{print $2}'|xargs kill -9 &> /dev/null
	ps -ef |grep admin-server|grep -v "grep"|awk '{print $2}'|xargs kill -9 &> /dev/null
	ps -ef |grep app-server|grep -v "grep"|awk '{print $2}'|xargs kill -9 &> /dev/null
	ps -ef |grep firstparty-server|grep -v "grep"|awk '{print $2}'|xargs kill -9 &> /dev/null
	ps -ef |grep outsource-server|grep -v "grep"|awk '{print $2}'|xargs kill -9 &> /dev/null
sleep 10
}


check_course(){
#检查是否已将进程杀死了，如值大于2则说明未杀死
	CHECK=`ps -ef |grep task-rpc |wc -l`
	[ $CHECK -ge 2 ] && return 12
	CHECK=`ps -ef |grep repay-rpc|wc -l`
	[ $CHECK -ge 2 ] && return 12
	CHECK=`ps -ef |grep report-rpc|wc -l`
	[ $CHECK -ge 2 ] && return 12
	CHECK=`ps -ef |grep admin-server|wc -l`
	[ $CHECK -ge 2 ] && return 12
	CHECK=`ps -ef |grep app-server|wc -l`
	[ $CHECK -ge 2 ] && return 12
	CHECK=`ps -ef |grep firstparty-server|wc -l`
	[ $CHECK -ge 2 ] && return 12
	CHECK=`ps -ef |grep outsource-server|wc -l`
	[ $CHECK -ge 2 ] && return 12
}



drop_code(){
#删除原来数据
	cd /opt/server/OneCollection/onecollection-rpc/repay-rpc
	rm -rf * && sleep 1
	cd /opt/server/OneCollection/onecollection-rpc/task-rpc
	rm -rf * && sleep 1
	cd /opt/server/OneCollection/onecollection-rpc/report-rpc
	rm -rf * && sleep 1
	cd /opt/server/OneCollection/onecollection-cgi/app-server
	rm -rf * && sleep 1
	cd /opt/server/OneCollection/onecollection-cgi/admin-server
	rm -rf * && sleep 1
	cd /opt/server/OneCollection/onecollection-cgi/firstparty-server
	rm -rf * && sleep 1
	cd /opt/server/OneCollection/onecollection-cgi/outsource-server
	rm -rf * && sleep 1
}

cp_code(){
	[ $ENVI == dev ] && DIRNAME=data
	[ $ENVI == pre ] && DIRNAME=www
	[ $ENVI == prod ] && DIRNAME=www
	
	CODE=`ls /$DIRNAME |grep "admin-server" |grep $TIME`
	cp /$DIRNAME/$CODE /opt/server/OneCollection/onecollection-cgi/admin-server/

	CODE=`ls /$DIRNAME |grep "app-server" |grep $TIME`
	cp /$DIRNAME/$CODE /opt/server/OneCollection/onecollection-cgi/app-server/

	CODE=`ls /$DIRNAME |grep "firstparty-server" |grep $TIME`
	cp /$DIRNAME/$CODE /opt/server/OneCollection/onecollection-cgi/firstparty-server/

	CODE=`ls /$DIRNAME |grep "outsource-server" |grep $TIME`
	cp /$DIRNAME/$CODE /opt/server/OneCollection/onecollection-cgi/outsource-server/

	CODE=`ls /$DIRNAME |grep "report-provider" |grep $TIME`
	cp /$DIRNAME/$CODE /opt/server/OneCollection/onecollection-rpc/report-rpc/

	CODE=`ls /$DIRNAME |grep "task-provide" |grep $TIME`
	cp /$DIRNAME/$CODE /opt/server/OneCollection/onecollection-rpc/task-rpc/

	CODE=`ls /$DIRNAME |grep "repay-provider" |grep $TIME`
	cp /$DIRNAME/$CODE /opt/server/OneCollection/onecollection-rpc/repay-rpc/
}

#启动进程
start_course(){
	cd /opt/server/OneCollection/onecollection-rpc/repay-rpc
	unzip repay-provider-2.0.0-SNAPSHOT-bin.zip*
	cd bin && chmod 711 *.sh
	./start.sh product
	sleep 1
	cd /opt/server/OneCollection/onecollection-rpc/task-rpc
	unzip task-provider-2.0.0-SNAPSHOT-bin.zip*
	cd bin && chmod 711 *.sh
	./start.sh product
	sleep 1
	cd /opt/server/OneCollection/onecollection-rpc/report-rpc
	unzip report-provider-2.0.0-SNAPSHOT-bin.zip*
	cd bin && chmod 711 *.sh
	./start.sh product
	sleep 1

	cd /opt/server/OneCollection/onecollection-cgi/app-server
	unzip app-server-2.0.0-SNAPSHOT-bin.zip*
	cd bin && chmod 711 *.sh
	./start.sh product
	sleep 1
	cd /opt/server/OneCollection/onecollection-cgi/admin-server
	unzip admin-server-2.0.0-SNAPSHOT-bin.zip*
	cd bin && chmod 711 *.sh
	./start.sh product
	sleep 1
	cd /opt/server/OneCollection/onecollection-cgi/firstparty-server
	unzip firstparty-server-2.0.0-SNAPSHOT-bin.zip*
	cd bin && chmod 711 *.sh
	./start.sh product
	sleep 1
	cd /opt/server/OneCollection/onecollection-cgi/outsource-server
	unzip outsource-server-2.0.0-SNAPSHOT-bin.zip*
	cd bin && chmod 711 *.sh
	./start.sh product
	sleep 1
}


#检查目前存在的检查数
A=`jps |grep "2.0.0"|wc -l`

case $ENVI in
dev)
	ls ./time.txt &> /dev/null
	[ $? -ne 0 ] && echo "缺失time.txt文件" && exit 9
	ls ./check-package &> /dev/null
	[ $? -ne 0 ] && echo "缺失check-package文件" && exit 9
	TIME=`cat ./time.txt`
	[ $TIME -lt 1500000000 ] && echo "时间戳异常请检查" && exit 10

	#获取原来包的时间戳，可做对比判断
	CT=`ls /opt/server/OneCollection/onecollection-cgi/admin-server/admin-server-2.0.0-SNAPSHOT-bin.zip*`
	CTY=`echo $CT| cut -d "_" -f2`
	[ $TIME -eq $CTY ] && echo "时间搓一致，无须替换" && exit 11
	#检查要更新的包是否存在
	while read LINE;do
        	ls /data/${LINE##*/}_"$TIME"* &> /dev/null
        	[ $? -ne 0 ] && echo "未找到该文件 ${LINE##*/}_$TIME" && exit 8
	done <  ./check-package

	for  I  in  `seq 1 7`;do
		kill_course
		check_course
		[ $? -ne 12 ] && break 	
	done
	;;
*)
	[ $A -gt 0 ] && echo "程序进程还未停止,请手动关闭" && exit 21
	read -p "请确保nginx不会将新的请求发送到本台机子上" VER
        #手动暂时程序命令，请确保nginx不会代理到本台机子上
        #ps -ef |grep task-rpc|grep -v "grep"|awk '{print $2}'|xargs kill 
        #ps -ef |grep repay-rpc|grep -v "grep"|awk '{print $2}'|xargs kill 
        #ps -ef |grep report-rpc|grep -v "grep"|awk '{print $2}'|xargs kill 
        #ps -ef |grep admin-server|grep -v "grep"|awk '{print $2}'|xargs kill 
        #ps -ef |grep app-server|grep -v "grep"|awk '{print $2}'|xargs kill 
        #ps -ef |grep firstparty-server|grep -v "grep"|awk '{print $2}'|xargs kill 
        #ps -ef |grep outsource-server|grep -v "grep"|awk '{print $2}'|xargs kill
	
	sleep 5

	clear
	hint(){
	if [ $ENVI == pre ];then
		TIME_t=`ls /www |grep "bin.zip"| grep "pre" | cut -d "_" -f2 |sort -rn |uniq | head -1`	
	elif [ $ENVI == prod];then
		TIME_t=`ls /www |grep "bin.zip"| grep "prod" | cut -d "_" -f2 |sort -rn |uniq | head -1`
	fi
	TIME_c=`date -d @$TIME_t`
	echo "$TIME_t  对应时间:$TIME_c"
	}
	hint
	while    :; do
		read -p "请确认程序包生成时间是否正确,并输入进行核对,取消请输入"q"
>>>" TIME_ROLL
		[ $TIME_ROLL == q ] && exit 0
		[ $TIME_ROLL == $TIME_t ] &> /dev/null
		if [ $? -ne 0 ];then
			echo "不存在该时间版本，请重新输入" 
			continue
		else
			read -p "请确认一下是否要升级到$TIME_ROLL版本,版本生产时间为`date -d @$TIME_ROLL`,确认请输入"y"
>>>" TIME_ROLL_2
			if [ $TIME_ROLL_2 == y ];then 
				break
			else
				clear
				hint
				continue				
			fi
		fi
	done

	TIME="$TIME_ROLL"		
	#检查要更新的包是否存在
	while read LINE;do
        	ls /data/${LINE##*/}_"$TIME"* &> /dev/null
        	[ $? -ne 0 ] && echo "未找到该文件 ${LINE##*/}_$TIME" && exit 8
	done <  ./check-package
	for  I  in  `seq 1 7`;do
		check_course
	[ $? -ne 12 ] && break 	
	done
	;;
esac

check_course
[ $? -eq 12 ] && echo "不能正常结束原有进程，请检查" && exit 13
#删除原有code
drop_code
#cp本次要更新的code
cp_code
#启动进程
start_course

sleep 15
B=`jps |grep "2.0.0"|wc -l`
[ $A -le $B ] && echo "更新成功" && cd /root/.devops && sh weixin_massage.sh "更新完毕，请验证" && exit 0

kill_course
sleep 2
start_course

sleep 10
B=`jps |grep "2.0.0"|wc -l`
[ $A -le $B ] && echo "更新成功" && cd /root/.devops && sh weixin_massage.sh "更新完毕，请验证" && exit 0

cd /root/.devops && sh ./check_port.sh && [ $? -eq 0 ] && sh weixin_massage.sh "更新完毕，请验证" && exit 0

echo "A=$A"
echo "B=$B"
[ $A -ne $B ] && echo "失败请检查进程无法启动原因" && cd /root/.devops && sh weixin_massage.sh "更新失败，请检查" && exit 22