#!/bin/bash
#

#dafy_dev_port_check
#ansible dev2 -m shell -a "cd /root/.devops && sh check_port.sh"

#检查端口是否已占用


PORT="60000 60001 60002 60003 50004 50005 50008 2181"

B=0
C=0
for  I  in  $PORT ;do  
	#echo $I

	netstat -lntp |grep $I |grep java &> /dev/null
	A=$?
	if [ $A -eq 0 ];then
		echo "端口$I已启动，服务正常"
	else
		echo "端口$I未启动，服务异常，请检查对应的日志信息"
		let C=$B+1
	fi
done

D=`jps |grep 2.0.0`

for I in "admin-server" "app-server" "firstparty-server" "outsource-server" "task-provider" "repay-provider" "report-provider"; do
        echo $D | grep "$I" &> /dev/null
        E=$?
        if [ $E -eq 0 ];then
                echo "进程已启动  $I"
        else
                echo "进程未启动  $I"
        fi
done

if [ $C -ge 1 ];then
	exit 7
fi
