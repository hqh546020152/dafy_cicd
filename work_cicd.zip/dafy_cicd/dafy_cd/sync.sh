#!/bin/bash
#



A=`jps |grep "2.0.0" -v |grep jar |cut -d" " -f1`
B=`ps -ef |grep data-sync|grep -v "grep"|awk '{print $2}'`

start_data(){
	cd /opt/server/OneCollection/onecollection-rpc/data-sync

	nohup java -jar -server -Xmx512m -Xms256m -Xmn128m -Xss256k -XX:SurvivorRatio=4 -XX:MaxTenuringThreshold=3 -XX:-UseGCOverheadLimit -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=/opt/logs/onecollection/data-sync/ -XX:+DisableExplicitGC -XX:ParallelGCThreads=8 -XX:+UseConcMarkSweepGC -XX:+CMSParallelRemarkEnabled -XX:+UseCMSCompactAtFullCollection -verbose:gc -XX:+PrintHeapAtGC -XX:+PrintGCApplicationStoppedTime -XX:+PrintGCApplicationConcurrentTime -Xloggc:/opt/logs/onecollection/data-sync/gc.log -XX:LargePageSizeInBytes=64m -XX:+UseFastAccessorMethods -XX:+UseCMSInitiatingOccupancyOnly -XX:CMSInitiatingOccupancyFraction=70 data-sync-2.0.0-SNAPSHOT.jar -Ddubbo.shutdown.hook=true --spring.profiles.active=product>/opt/logs/onecollection/data-sync/debug.log 2>/opt/logs/onecollection/data-sync/error.log &
}


if [ $A -eq $B ];then
	kill -9 $A
	start_data
	exit 0
elif [ $A -z ];then
	start_data
else
	echo "无法判定data-sync进程，请手动处理！"
	exit 2
fi
	

