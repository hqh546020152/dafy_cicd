#!/bin/bash
#

#使用方法：sh weixin_massage.sh "通知内容"
#将会发布通知给user中的用户

user="xiaoqing WuWeiBing HuangQiHuan YangYongQing TaoYing WenPeng Laihaida"
#user="TaoYing"
#user="HuangQiHuan"
corpid=ww9bee3da6fceb8f8b
corpsecret=nqw6esu5wH6pOtADIEhGlScmPlZG1MwgChomrWRNSM4
msg=$1
agentld=1000004


[ $msg -z ] &> /dev/null
[ $? -eq 0 ] && echo "无传入通知内容，请重新调用" && exit 20


for I in $user;do
        echo $I

        ./wechat --corpid="$corpid"  --corpsecret="$corpsecret"   --msg="$msg" --user="$I"  --agentid="$agentld"

done

echo "已发送通知消息"
